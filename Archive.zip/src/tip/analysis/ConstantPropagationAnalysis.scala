package tip.analysis

import tip.ast.AstNodeData.DeclarationData
import tip.cfg.{InterproceduralProgramCfg, IntraproceduralProgramCfg}
import tip.lattices.ConstantPropagationLattice

object ConstantPropagationAnalysis {

  object Intraprocedural {

    /**
      * Intraprocedural analysis that uses the simple fixpoint solver.
      */
    class SimpleSolver(cfg: IntraproceduralProgramCfg)(implicit declData: DeclarationData)
        extends IntraprocValueAnalysisSimpleSolver(cfg, ConstantPropagationLattice)

    /**
      * Intraprocedural analysis that uses the worklist solver.
      */
    class WorklistSolver(cfg: IntraproceduralProgramCfg)(implicit declData: DeclarationData)
        extends IntraprocValueAnalysisWorklistSolver(cfg, ConstantPropagationLattice)

    /**
      * Intraprocedural analysis that uses the worklist solver with reachability.
      */
    class WorklistSolverWithReachability(cfg: IntraproceduralProgramCfg)(implicit declData: DeclarationData)
        extends IntraprocValueAnalysisWorklistSolverWithReachability(cfg, ConstantPropagationLattice)

    /**
      * Intraprocedural analysis that uses the worklist solver with reachability and propagation-style.
      */
    class WorklistSolverWithReachabilityAndPropagation(cfg: IntraproceduralProgramCfg)(implicit declData: DeclarationData)
        extends IntraprocValueAnalysisWorklistSolverWithReachabilityAndPropagation(cfg, ConstantPropagationLattice)
  }

  object Interprocedural {

    /**
      * Interprocedural analysis that uses the worklist solver with reachability.
      */
    class WorklistSolverWithReachability(cfg: InterproceduralProgramCfg)(implicit declData: DeclarationData)
        extends InterprocValueAnalysisWorklistSolverWithReachability(cfg, ConstantPropagationLattice)

    /**
      * Interprocedural analysis that uses the worklist solver with reachability and propagation-style.
      */
    class WorklistSolverWithReachabilityAndPropagation(cfg: InterproceduralProgramCfg)(implicit declData: DeclarationData)
        extends InterprocValueAnalysisWorklistSolverWithReachabilityAndPropagation(cfg, ConstantPropagationLattice)

    /**
      * Interprocedural analysis that uses the worklist solver with reachability and propagation-style.
      * with call-string context sensitivity.
      */
    class CallString(cfg: InterproceduralProgramCfg)(implicit declData: DeclarationData) extends CallStringValueAnalysis(cfg, ConstantPropagationLattice)

    /**
      * Interprocedural analysis that uses the worklist solver with reachability and propagation-style.
      * with functional-approach context sensitivity.
      */
    class Functional(cfg: InterproceduralProgramCfg)(implicit declData: DeclarationData) extends FunctionalValueAnalysis(cfg, ConstantPropagationLattice)
  }
}
